import AllProjects from "@/components/Projects/AllProjects";
import React from "react";

const ProjectsPage = () => {
  return (
    <>
      <AllProjects />
    </>
  );
};

export default ProjectsPage;
