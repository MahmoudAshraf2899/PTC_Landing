//  import Project from "@/components/Projects/Project";
import Project from "@/components/Projects/Project";
import React from "react";

const ProjectNormalPage = () => {
  return (
    <>
      {" "}
      <Project />
    </>
  );
};

export default ProjectNormalPage;
