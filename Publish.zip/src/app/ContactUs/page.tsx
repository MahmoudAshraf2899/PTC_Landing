import ContactUs from "@/components/ContactUs/ContactUs";
import React from "react";

const ContactUsPage = () => {
  return (
    <>
      <ContactUs />
    </>
  );
};

export default ContactUsPage;
