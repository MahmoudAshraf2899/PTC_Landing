import Constructions from "@/components/Constructions/Constructions";
import React from "react";

const ConstructionPage = () => {
  return (
    <>
      <Constructions />
    </>
  );
};

export default ConstructionPage;
