import Project from "@/components/Projects/Project";
import React from "react";

const ProjectPage = () => {
  return (
    <>
      <Project />
    </>
  );
};

export default ProjectPage;
