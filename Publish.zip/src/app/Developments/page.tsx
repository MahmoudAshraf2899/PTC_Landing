import Developments from "@/components/Developments/Developments";
import React from "react";

const DevelopmentPage = () => {
  return (
    <>
      <Developments />
    </>
  );
};

export default DevelopmentPage;
