import AboutUs from "@/components/AboutUs/AboutUs";
import React from "react";

const AboutUsPage = () => {
  return (
    <>
      <AboutUs />
    </>
  );
};

export default AboutUsPage;
