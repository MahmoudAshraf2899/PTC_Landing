import PrivacyPolicy from "@/components/PrivacyPolicy/PrivacyPolicy";
import React from "react";

const PrivacyPolicyPage = () => {
  return (
    <>
      <PrivacyPolicy />
    </>
  );
};

export default PrivacyPolicyPage;
